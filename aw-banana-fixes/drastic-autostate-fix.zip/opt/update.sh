#!/bin/sh

DRASTIC_T_JSON="$(cat "/run/muos/device/storage/rom/mount")/MUOS/emulator/drastic-trngaje/resources/settings.json"
if [ -f "$DRASTIC_T_JSON" ]; then
	sed -i 's/"auto_state":1/"auto_state":0/' "$DRASTIC_T_JSON"
fi
