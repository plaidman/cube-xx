#!/bin/sh

touch "/mnt/mmc/MUOS/update/installed/CubeXXSpeakerSwap.zip.done"
/opt/muos/script/mux/quit.sh reboot frontend