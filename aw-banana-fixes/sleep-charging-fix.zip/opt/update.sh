#!/bin/sh

. /opt/muos/script/var/func.sh

dd if="/opt/dtb/$DEVICE_TYPE/package/boot_package.fex" of='/dev/mmcblk0' bs=1k seek=16400
if [ $? -ne 0 ]; then
    echo "Error writing boot package to /dev/mmcblk0"
fi

rm -f "/opt/dtb.zip"
touch "/mnt/mmc/MUOS/update/installed/sleep-charging-fix.zip.done"

/opt/muos/script/mux/quit.sh reboot frontend
