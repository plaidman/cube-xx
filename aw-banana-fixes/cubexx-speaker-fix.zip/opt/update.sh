#!/bin/sh

touch "/mnt/mmc/MUOS/update/installed/cubexx-speaker-fix.zip.done"
/opt/muos/script/mux/quit.sh reboot frontend