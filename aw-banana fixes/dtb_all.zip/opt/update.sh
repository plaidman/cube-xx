#!/bin/sh

CURR_BUILDID=$(sed -n '2p' /opt/muos/config/version.txt)
case "$CURR_BUILDID" in
	*)
		unzip -q -o "/opt/dtb.zip" opt/muos/bin/pv opt/muos/script/mux/extract.sh -d /
		/opt/muos/script/mux/extract.sh "/opt/dtb.zip"
		;;
	*)
		rm -f "/opt/dtb.zip"

		echo "This update is for BUILD ID of '*' only!"
		echo "You are currently on '$CURR_BUILDID'"
		echo ""
		echo "If this is a genuine error, please report it!"

		sleep 10

		;;
esac
